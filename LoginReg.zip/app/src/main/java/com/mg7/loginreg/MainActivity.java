package com.mg7.loginreg;

import android.content.Intent;
//import android.support.v7.app.AppCompatActivity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private de.hdodenhof.circleimageview.CircleImageView circleImageView;

    private byte[] imageBytes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        circleImageView = findViewById(R.id.profile_pic_userarea);

        Intent intent = getIntent();
        String name = intent.getStringExtra("Name");
        String username = intent.getStringExtra("Username");
        String PicString = intent.getStringExtra("Pic");
        int age = intent.getIntExtra("Age", -1);

        TextView tvWelcomeMsg = (TextView) findViewById(R.id.tvWelcomeMsg);
        EditText etUsername = (EditText) findViewById(R.id.etUsername);
        EditText etAge = (EditText) findViewById(R.id.etAge);


        //decode base64 string to image
        imageBytes = Base64.decode(PicString, Base64.DEFAULT);
        Bitmap decodedImage = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);


        // Display user details
        String message = name + " Welcome to your user area";
        tvWelcomeMsg.setText(message);
        etUsername.setText(username);
        etAge.setText(age + "");
        circleImageView.setImageBitmap(decodedImage);
    }
}